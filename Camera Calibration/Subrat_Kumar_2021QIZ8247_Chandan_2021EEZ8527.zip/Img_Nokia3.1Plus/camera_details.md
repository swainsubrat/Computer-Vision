#Smartphone Details
Phone Name: Nokia 3.1 Plus
Rear Camera: 13MP f/2.0
